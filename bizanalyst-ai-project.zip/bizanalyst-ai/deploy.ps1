# ============================================
# BizAnalyst AI — One-Command Deploy (Windows)
# ============================================
# Run this in PowerShell and your app will be live in ~2 minutes
#
# PREREQUISITES:
#   1. Node.js installed (download from nodejs.org)
#   2. This zip file unzipped
#
# USAGE:
#   cd bizanalyst-ai
#   powershell -ExecutionPolicy Bypass -File deploy.ps1
# ============================================

Write-Host ""
Write-Host "  ================================================" -ForegroundColor Cyan
Write-Host "        BizAnalyst AI Deployer (Windows)          " -ForegroundColor Cyan
Write-Host "  ================================================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
try {
    $nodeVersion = node -v
    Write-Host "  OK Node.js $nodeVersion found" -ForegroundColor Green
} catch {
    Write-Host "  X  Node.js not found. Download from https://nodejs.org" -ForegroundColor Red
    exit 1
}

# Install dependencies
Write-Host ""
Write-Host "  Installing dependencies..." -ForegroundColor Yellow
npm install --silent 2>$null
Write-Host "  OK Dependencies installed" -ForegroundColor Green

# Install Vercel CLI
$vercelInstalled = Get-Command vercel -ErrorAction SilentlyContinue
if (-not $vercelInstalled) {
    Write-Host ""
    Write-Host "  Installing Vercel CLI..." -ForegroundColor Yellow
    npm install -g vercel --silent 2>$null
    Write-Host "  OK Vercel CLI installed" -ForegroundColor Green
} else {
    Write-Host "  OK Vercel CLI found" -ForegroundColor Green
}

# Login
Write-Host ""
Write-Host "  Checking Vercel login..." -ForegroundColor Yellow
Write-Host "  (A browser window may open - log in with your Vercel account)" -ForegroundColor Gray
try {
    vercel whoami 2>$null
} catch {
    vercel login
}

# Deploy
Write-Host ""
Write-Host "  Deploying to Vercel..." -ForegroundColor Yellow
Write-Host "  (Press Enter to accept defaults)" -ForegroundColor Gray
Write-Host ""
vercel --prod --yes

Write-Host ""
Write-Host "  ================================================" -ForegroundColor Green
Write-Host "     BizAnalyst AI is LIVE!                       " -ForegroundColor Green
Write-Host "  ================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Your app URL is shown above" -ForegroundColor White
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor Gray
Write-Host "  1. Visit your URL to see the app" -ForegroundColor Gray
Write-Host "  2. Set up Stripe at stripe.com" -ForegroundColor Gray
Write-Host "  3. Buy a custom domain (optional)" -ForegroundColor Gray
Write-Host ""
