#!/bin/bash
# ============================================
# BizAnalyst AI — One-Command Deploy Script
# ============================================
# Run this and your app will be live in ~2 minutes
# 
# PREREQUISITES:
#   1. Node.js installed (download from nodejs.org)
#   2. This zip file unzipped
#
# USAGE:
#   cd bizanalyst-ai
#   chmod +x deploy.sh
#   ./deploy.sh
# ============================================

set -e

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║       BizAnalyst AI Deployer         ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Download it from https://nodejs.org"
    echo "   Get the LTS version, install it, then re-run this script."
    exit 1
fi
echo "✅ Node.js $(node -v) found"

# Check npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm not found. It should come with Node.js."
    exit 1
fi
echo "✅ npm $(npm -v) found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install --silent 2>&1
echo "✅ Dependencies installed"

# Install Vercel CLI if needed
if ! command -v vercel &> /dev/null; then
    echo ""
    echo "📦 Installing Vercel CLI..."
    npm install -g vercel --silent 2>&1
    echo "✅ Vercel CLI installed"
else
    echo "✅ Vercel CLI found"
fi

# Login check
echo ""
echo "🔑 Checking Vercel login..."
echo "   (If a browser window opens, log in with your Vercel account)"
vercel whoami 2>/dev/null || vercel login

# Deploy
echo ""
echo "🚀 Deploying to Vercel..."
echo "   (Accept the defaults by pressing Enter for each question)"
echo ""
vercel --prod --yes

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║    🎉 BizAnalyst AI is LIVE! 🎉     ║"
echo "  ╚══════════════════════════════════════╝"
echo ""
echo "  Your app URL is shown above ☝️"
echo ""
echo "  Next steps:"
echo "  1. Visit your URL to see the app"
echo "  2. Set up Stripe at stripe.com"
echo "  3. Buy a custom domain (optional)"
echo ""
