# BizAnalyst AI

AI-powered business analytics. Upload any CSV and get instant insights, charts, and recommendations.

## Quick Start (Local)

```bash
npm install
npm start
```

Opens at http://localhost:3000

## Deploy to Vercel (Go Live)

```bash
npm install -g vercel
vercel login
vercel --prod
```

Your app will be live at `your-project.vercel.app` in ~60 seconds.

## Stripe Setup

1. Create account at stripe.com
2. Create products/prices in Stripe Dashboard
3. Update `STRIPE_CONFIG` in `src/App.js` with your price IDs
4. Add `STRIPE_SECRET_KEY` to Vercel environment variables
